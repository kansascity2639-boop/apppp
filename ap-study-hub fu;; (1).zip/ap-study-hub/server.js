// AP Study Hub static server. Everything runs in the browser, so this just serves /public.
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  next();
});
app.use(
  express.static(path.join(__dirname, "public"), {
    maxAge: "1h",
    setHeaders(res, filePath) {
      if (filePath.endsWith("index.html") || filePath.endsWith("data.js")) res.setHeader("Cache-Control", "no-cache");
    },
  })
);
app.get("/healthz", (req, res) => res.json({ ok: true }));
app.use((req, res) => res.status(404).sendFile(path.join(__dirname, "public", "index.html")));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`AP Study Hub running at http://localhost:${PORT}`));
